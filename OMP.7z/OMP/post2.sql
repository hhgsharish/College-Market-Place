-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2015 at 05:36 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `post2`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--
use post2;

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `hash` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `hash`) VALUES
(1, 'harish', '1234'),
(6, 'Amos', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `freead`
--

CREATE TABLE IF NOT EXISTS `freead` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cat_id` int(10) unsigned NOT NULL,
  `ad_title` varchar(45) NOT NULL,
  `photo_name` varchar(45) NOT NULL,
  `description` text NOT NULL,
  `price` int(10) unsigned NOT NULL,
  `contact_name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `m_number` decimal(10,0) unsigned NOT NULL,
  `address` text NOT NULL,
  `college` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`,`cat_id`),
  KEY `FK_freead_1` (`cat_id`),
  FULLTEXT KEY `ad_title` (`ad_title`,`description`,`address`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=44 ;

--
-- Dumping data for table `freead`
--

INSERT INTO `freead` (`id`, `cat_id`, `ad_title`, `photo_name`, `description`, `price`, `contact_name`, `email`, `m_number`, `address`, `college`) VALUES
(33, 3, 'Micromax canvas 4 for sell just 12 month old ', 'micro.JPG', 'only three months old ', 5000, 'Santhosh', 'san@gmail.com', '4294967295', '1 km before ecity', 'PESIT'),
(40, 1, 'Dell Vostro with a neat condition just only 5', 'l1.JPG', 'Processor : Intel Core 2 Duo\r\n\r\nIntel Graphics HD 1GB graphic \r\nVariantHD X4500M\r\n\r\nColors : Black\r\nWeight : 2.2 Kg\r\nDisplay Features Wide Display HD with TrueLifeDisplay Resolution1366 x 768 PixelsDisplay Size14.1 Inches\r\nDisplay Type : LED\r\n\r\nExpandable Memory 8 GB Memory Slots 2 \r\nRAM : 2GB DDR3\r\n\r\nHard disk : 250GB \r\n\r\nBattery backup : 3hours\r\n\r\nWireless LAN802.11 b/g/n\r\nBluetoothYesBluetooth Version2.1\r\nUSB 2.0 \r\nslots 3 HDMI 1\r\nWeb-cam Yes \r\nWeb-cam resolution : 1.3 MP\r\n\r\nprice is fixed 12000Rs', 20000, 'Saleem', 'ss@gmail.com', '9731728986', 'hsr layout', 'PESIT BSC'),
(37, 2, 'Children story books2', 'craft.JPG', 'new , maintained in well condition', 200, 'vijetha', 'hh@gmail.com', '4294967295', 'madivaala', 'PESIT'),
(39, 1, 'INSPIRON i3 laptop - 500gb HDD / 2gb RAM - 4h', 'l.JPG', 'INSPIRON i3 laptop - 500gb HDD / 2gb RAM - 4hors battery back up', 25000, 'Harsha Patil', 'hh@gmail.com', '9731728986', 'singasandra', 'PESIT'),
(36, 2, 'Children story books', 'rusy.JPG', 'Children story books', 500, 'Bharat', 'hh@gmail.com', '955959', '1km from ecity', 'PESIT'),
(31, 3, 'I want to sell my Samsung Galaxy grand prime.', 'Capture.JPG', 'Only 5 months use...\r\nAccessories _ Bill, Box, Charger and earphone....\r\nPlz call me and whatsapp me...', 9000, 'Affan khan', 'affan@gmail.com', '4294967295', 'Parappana Agrahara ', 'PESIT'),
(32, 4, 'Best quality gsm coin box', 'ctd.JPG', 'In India, manned and automated (coin operated payphone) versions of the service are in existence. BSNL, a public sector corporation, has the largest installation of PCOs in India. Mr. R. L. Dube, a Dept of Telecom officer, introduced concept of PCOs in India.', 200, 'Shadakshari', 'Shadakshari@gmail.com', '4294967295', '1 KM after electronic city', 'PESIT'),
(38, 2, 'PHP with MySQL 5 courses 34 Hours Video Train', 'vid.JPG', 'PHP with MySQL 5 courses 34 Hours Video Training DVD Rs 350', 350, 'Amos', 'hh@gmail.com', '4294967295', 'banashankari', 'PESIT'),
(41, 1, 'Lenovo ideapad s210 touch screen corei3 3rd g', 'l3.JPG', 'Intel corei3 3rd gen processor\r\n\r\n4gb ddr3 ram\r\n\r\n500gb hdd\r\n\r\nWifi\r\n\r\nCam\r\n\r\nBlue tooth\r\n\r\nWin 8 Original with recovery\r\n', 22000, 'Sudarshan', 'hh@gmail.com', '9945858585', 'pesit', 'PESIT'),
(42, 4, 'Targus Trek Backpack for 16 inch Laptop', 'b.JPG', 'GENERAL SPECIFICATIONS\r\nBrand - Targus\r\nModel - TSB193US-70\r\nWeight - 399.16 g\r\nType - Laptop Backpack\r\nModel Name - Trek\r\nMaterial - Polyester\r\nCapacity - 16 inch\r\nNumber of Compartments	2\r\nColor - Black', 900, 'Abhilash', 'abhi@gmail.com', '9945858585', 'pesit', 'PESIT'),
(43, 4, 'Ray ban clubmaster 3016 sunglass', 'g.JPG', 'brown frame (tiger) brown lens\r\n1. R B Logo engraved on Left Lens\r\n\r\n2. R B Logo engraved on Right Lens\r\n\r\n3. R B Made in Italy on Right Frame Arm\r\n\r\n4. R B Complete Model name along with size on Left Frame Arm\r\n\r\n5. Metal \r\n\r\n6.R B box,cover case,clothing', 600, 'naveen', 'hh@gmail.com', '9731728986', 'pesit', 'PESIT');

-- --------------------------------------------------------

--
-- Stand-in structure for view `new`
--
CREATE TABLE IF NOT EXISTS `new` (
`cat_id` int(11) unsigned
,`ad_title` varchar(45)
,`photo_name` varchar(45)
,`description` text
,`price` int(11) unsigned
,`contact_name` varchar(45)
,`email` varchar(45)
,`m_number` varchar(45)
,`address` text
,`college` varchar(50)
);
-- --------------------------------------------------------

--
-- Table structure for table `sub_heading`
--

CREATE TABLE IF NOT EXISTS `sub_heading` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sub_id` int(10) unsigned NOT NULL,
  `sub_title` varchar(45) NOT NULL,
  `position` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`,`sub_id`),
  KEY `FK_sub_heading_1` (`sub_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=81 ;

--
-- Dumping data for table `sub_heading`
--

INSERT INTO `sub_heading` (`id`, `sub_id`, `sub_title`, `position`) VALUES
(1, 1, 'Animals', 1),
(2, 1, 'Art-Collections', 2),
(3, 1, 'Books-Magzines', 3),
(4, 1, 'Bussiness-Industrial', 4),
(5, 1, 'Cameras-Camera Accessories', 5),
(6, 1, 'Cars', 6),
(7, 1, 'Car parts', 7),
(8, 1, 'CDs-Records', 8),
(9, 1, 'Cell Phones-Accessories', 9),
(10, 1, 'Clothing', 10),
(11, 1, 'Computer Hardware', 11),
(12, 1, 'DVD', 12),
(13, 1, 'Electronics', 13),
(14, 1, 'For Babies_ Infants', 14),
(15, 1, 'Garage Sale', 15),
(18, 1, 'Jewelery', 16),
(19, 1, 'Musical Instruments', 17),
(20, 1, 'Motorcycles-Scooters', 18),
(21, 1, 'Sporting Goods-Bicycles', 19),
(22, 1, 'Tickets', 20),
(23, 1, 'Toys-Games', 21),
(24, 1, 'Video Games-Consoles', 22),
(25, 2, 'Carpool', 1),
(26, 2, 'Community Activities', 2),
(27, 2, 'Events', 3),
(28, 2, 'Musicians-Artists-Brands', 4),
(29, 2, 'Volunteers', 5),
(30, 2, 'Lost and Found', 6),
(31, 3, 'Accounting Jobs - Finance Jobs', 1),
(32, 3, 'Advertising Jobs - Public Relations Jobs', 2),
(33, 3, 'Arts Jobs - Entertainment Jobs', 3),
(34, 3, 'Publishing Jobs', 4),
(35, 3, 'Clerical Jobs - Administratice Jobs', 5),
(36, 3, 'Customer Service Jobs', 6),
(37, 3, 'Clerical Jobs - Administrative Jobs', 7),
(38, 3, 'Customer Service Jobs', 8),
(39, 3, 'Customer Service Jobs', 9),
(40, 3, 'Education Jobs - Teaching Jobs', 10),
(41, 3, 'Engineering Jobs - Architecture Jobs', 11),
(42, 3, 'Healthcare Jobs', 12),
(43, 3, 'Hotel Jobs - Travel Jobs', 13),
(44, 3, 'Internal Jobs', 14),
(45, 3, 'Legal Jobs', 15),
(46, 3, 'Manual Labor Jobs', 16),
(47, 3, 'Manufacturing Jobs - Operations Jobs', 17),
(48, 3, 'Marketing Jobs', 18),
(49, 3, 'Non-Profite Jobs', 19),
(50, 3, 'Resturant Jobs - Food Service Jobs', 20),
(51, 3, 'Retail Jobs', 21),
(52, 3, 'Sales Jobs', 22),
(53, 3, 'Technology Jobs', 23),
(54, 4, 'Computer - Multimedia Classes', 1),
(55, 4, 'Language Classes', 2),
(56, 4, 'Music -Theatre - Dance Classes', 3),
(57, 4, 'Tutoring - Private Lessons', 4),
(58, 5, 'Houses - Apartements for Sale', 1),
(59, 5, 'Houses - Apartements for Rent', 2),
(60, 5, 'Rooms for Rent - Shared', 3),
(61, 5, 'Housing Swap', 4),
(62, 5, 'Vacation Rentals', 5),
(63, 5, 'Parking Spots', 6),
(64, 5, 'Land', 7),
(65, 5, 'Office - Commercial Space', 8),
(66, 5, 'Shops for Rent - Sale', 9),
(67, 6, 'Babysitter - Nanny', 1),
(68, 6, 'Casting - Auditions', 2),
(69, 6, 'Chauffeur- Driver', 3),
(70, 6, 'Health - Beauty - Fitness', 4),
(71, 6, 'House hold - Domestic Help', 5),
(72, 6, 'Moving - Storage', 6),
(73, 6, 'Repair', 7),
(74, 6, 'Writing - Editing - Translating', 8),
(75, 6, 'Matrimonial', 9),
(76, 6, 'Brides', 10),
(77, 6, 'Groomes', 11);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `f_name` varchar(45) NOT NULL,
  `l_name` varchar(45) NOT NULL,
  `u_email` varchar(45) NOT NULL,
  `u_hash` varchar(45) NOT NULL,
  `username` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=21 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `f_name`, `l_name`, `u_email`, `u_hash`, `username`) VALUES
(18, 'hhh', 'hhh', 'hhh', 'hhhh', 'hhh'),
(17, 'ppp', 'ppp', 'ppp', 'ppp', 'ppp'),
(16, 'kkk', 'kkk', 'kkk', 'kkk', 'kkk'),
(15, 'ggg', 'ggg', 'ggg', 'ggg', 'ggg'),
(19, 'Harsha', 'Patil', 'hari6120@gmail.com', '1234', 'harsha'),
(20, 'Moloy', 'moloy', 'moloy@gmail.com', 'moloy', 'moloy');

-- --------------------------------------------------------

--
-- Table structure for table `userad`
--

CREATE TABLE IF NOT EXISTS `userad` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cat_id` int(10) unsigned NOT NULL,
  `ad_title` varchar(45) NOT NULL,
  `photo_name` varchar(45) NOT NULL,
  `description` text NOT NULL,
  `price` int(10) unsigned NOT NULL,
  `contact_name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `m_number` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  `u_name` varchar(45) NOT NULL,
  `college` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`,`cat_id`,`u_name`) USING BTREE,
  KEY `FK_userad_1` (`cat_id`),
  FULLTEXT KEY `ad_title` (`ad_title`,`description`,`address`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=31 ;

--
-- Dumping data for table `userad`
--

INSERT INTO `userad` (`id`, `cat_id`, `ad_title`, `photo_name`, `description`, `price`, `contact_name`, `email`, `m_number`, `address`, `u_name`, `college`) VALUES
(30, 3, 'Nice samsung gte2252 dual sim camera,multimed', 'Cap.JPG', 'Nice samsung gte2252 dual sim camera,multimedia, only mobile at 1000/-\r\nDual sim\r\nCamera\r\nMp3\r\nLong battery life.\r\nIn Rajender nagar', 1000, 'Revanna', 'revanna.Adhyaksha@gmail.com', '9874564566', 'rajendra nagar', 'kkk', 'PESIT'),
(29, 3, 'Nokia Lumia 525 Rarely used!!', 'image.jpg', 'Rarely used in good condition', 5000, 'moloy', 'moloy@gmail.com', '9945857558', 'pesit', 'moloy', 'Pesit');

-- --------------------------------------------------------

--
-- Structure for view `new`
--
DROP TABLE IF EXISTS `new`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `new` AS select `userad`.`cat_id` AS `cat_id`,`userad`.`ad_title` AS `ad_title`,`userad`.`photo_name` AS `photo_name`,`userad`.`description` AS `description`,`userad`.`price` AS `price`,`userad`.`contact_name` AS `contact_name`,`userad`.`email` AS `email`,`userad`.`m_number` AS `m_number`,`userad`.`address` AS `address`,`userad`.`college` AS `college` from `userad` union all select `freead`.`cat_id` AS `cat_id`,`freead`.`ad_title` AS `ad_title`,`freead`.`photo_name` AS `photo_name`,`freead`.`description` AS `description`,`freead`.`price` AS `price`,`freead`.`contact_name` AS `contact_name`,`freead`.`email` AS `email`,`freead`.`m_number` AS `m_number`,`freead`.`address` AS `address`,`freead`.`college` AS `college` from `freead`;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
