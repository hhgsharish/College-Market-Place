<?php
	error_reporting(0); 
	require_once("_includes/connection.php");
	require_once("_includes/functions.php");
	{
	$msg=$_GET['msg'];
}
?>

<!doctype html>


  

<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Free Classifieds..!</title>
    <link rel="stylesheet" href="css/foundation.css" />
	<link rel="stylesheet" href="css/mycss.css" />
    <script src="js/vendor/modernizr.js"></script>
	 <style type='text/css'>
      body{ background-image:url("128-36.jpg"); background-repeat:repeat; }
   </style>
  </head>
  
  
  <body>
  
  
    <div class="row">
      <div class="large-12 columns">
      	<div class="panel">
	        <h3>Welcome ...! <a href="register.php" value="" style="float:right">&nbsp&nbspRegister</a>
								<a href="login.php" value="" style="float:right" >Login</a></h3>
	        <h2>College Marketplace</h2>
	    </div>
		
			<?php echo $msg; ?>
		<div class="row">
    <div class="large-12 columns">
      <div class="row collapse">
        <div class="small-10 columns">
		
		<form method="post" name="search" action="search.php">
          <input type="text" placeholder="What are you looking for ?" name="search_text" required>
        </div>
	
        <div class="small-2 columns">
          <input type="submit" class="button postfix" name="search_button" value="Search"/>
		  <input type="hidden" name="search" value="mmm"  />
		 </form>
        </div>
		
		
		
      </div>
    </div>
  </div>
		
 
  
  <table  style="float: left" >
	<tr>
		<td><center><a href="showbooks.php"><img src="book.jpg" height="220" width="300"></a></center></td>
		<td><a href="showlaptop.php"><img src="laptop.jpg" height="220" width="300"></a></td>
	</tr>
	
	<tr>
		<td><center><a href="showbooks.php">Books</a></center></td>
		<td><center><a href="showlaptop.php">Laptops</a></center></td>
	</tr>
	
	<tr>
		<td><a href="showmobile.php"><img src="mobile.jpg" height="220" width="300"></a></td>
		<td><center><a href="showothers.php"><img src="kidcircle.jpg" height="220" width="300"></a><center></td>
	</tr>
	
	<tr>
		<td><center><a href="showmobile.php">Mobiles&Tablets</a></center></td>
		<td><center><a href="showothers.php">Others</a></center></td>
	</tr>
	
</table>
		
<table style="float:right">
<tr>
	<td><center><h3>Sell your items here</h3><center></td>
</tr>
<tr>
	<td><center>
	<a href="postad.php" class="button large" >Post a free Ad</a>
	<center></td>
</tr>
<tr>	
	<td>&nbsp;</td>
</tr>
<tr>
	<td><center><h3>Post For free</h3></center></td>
</tr>
<tr>
	<td><center><h3>Add Photos to your ad</h3></center></td>
</tr>
</table>

  
    </div>
	<hr>
	<table  id="footertab" align="center" width="100%">
	
	<tr>
		<td><center>Website Features</center></td>
		<td><center>Useful info</center></td>
		<td><center>Site Map</center></td>
	</tr>
	<tr>
		<td><center>->Post Ads</center></td>
		<td><center>Help</center></td>
		<td><center>find us on facebook</center></td>
	</tr>
	<tr>
		<td><center>->Find jobs</center></td>
		<td><center>Contact us</center></td>
		<td><center>twitter</center></td>
	</tr>
	
</table>
   </div>
   </div>
    
    <script src="js/vendor/jquery.js"></script>
    <script src="js/foundation.min.js"></script>
    <script>
      $(document).foundation();
    </script>
  </body>
</html>
