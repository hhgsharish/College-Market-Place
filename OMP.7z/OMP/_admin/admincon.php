<?php require_once("includes/session.php");?>
<?php
if(isset($_GET['msg']) && $_GET['msg']!='')
{
	$msg=$_GET['msg'];
}
error_reporting(0);
require_once('connection/connection.php');
$query="Select * from admin order by id asc";
$insertionquery=mysql_query($query);
?>


<!doctype html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Free Classifieds..!</title>
    <link rel="stylesheet" href="css/foundation.css" />
	<link rel="stylesheet" href="css/mycss.css" />
    <script src="js/vendor/modernizr.js"></script>
	<style type='text/css'>
      body{ background-image:url("128-36.jpg"); background-repeat:repeat; }
   </style>
  </head>
  
  
  <body>
  <div class="row">
      <div class="large-12 columns">
      	<div class="panel">
	        <a href="index.php" value="" class="button small">Control panel</a>
			<a href="manageads.php" value="" class="button small">&nbsp&nbsp&nbsp&nbsp&nbsp&nbspFree Ads</a>
			<a href="#" value="" class="button small">&nbsp&nbsp&nbsp&nbsp&nbsp&nbspUser Ads</a>
	        <pre><h4><a  href="includes/logout.php" >                                                                                                                        Logout</a></h4></pre>
	    </div>
		
		
		<div class="row">
    <div class="large-12 columns">
      <div class="row collapse">
        
        
      </div>
    </div>
  



<span><h4><?php echo $msg;?></h4></span>   

<div id="page">         
   	  <div id="table">   
		<form id="form" name="form" method="post" action="admininsert.php">

        	<table style="float:left">
            	
                
            	<tr>
                	<td colspan="2" id="tableh2"><b>Add new website Administrator</b></td>
            	</tr>
                
            	<tr>
                	<td width="130" class="text">Admin Name</td>
                    <td width="238"><input name="title" type="text" class="textfeilds"  value="<?php echo htmlentities($username); ?>" id="title" required></td>
            	</tr>
                <tr >
                	<td width="130" class="text">Password</td>
                    <td width="238"><input name="hash" type="password" class="textfeilds" value="<?php echo htmlentities($password); ?>" id="hash" required></td>
            	</tr>
                
            	<tr>
                	<td class="id1"></td>
                  <td><input type="submit" class="inputbutton" value="Add Now" />
                      <input name="admin" type="hidden" value="mmm" />
                  <input name="Reset" type="reset" class="inputbutton" id="button" value="Reset All" /></td>
            	</tr>
            </table>     
        </form>

      </div>
      
  		<div id="forshow">
   <table width="50%" style="float:right">
  <tr >
    <th >ID</td>
    <th >Username</td>
    <th >EDIT</td>
  </tr>
  <?php $k=1; while($get=mysql_fetch_array($insertionquery)) {?>
  <tr>
    <td><?php echo $get['id'];?></td>
    <td><?php echo $get['name'];?></td>
    <td><a href="editadmin.php?EDITC=<?php echo $get['id']?>"><img src="../_images/edit.png" /></a></td>
  </tr>
  <?php $k++; }?>
  </table>

      
      	</div>
 </div>     

    
			
</body>
</html>