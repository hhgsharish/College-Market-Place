<?php require_once("includes/session.php");?>
<?php
if(isset($_GET['msg']) && $_GET['msg']!='')
{
	$msg=$_GET['msg'];
}
error_reporting(0);
require_once('connection/connection.php');
$query="Select * from userad  ";
$insertionquery=mysql_query($query);

?>
<!doctype html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Free Classifieds..!</title>
    <link rel="stylesheet" href="css/foundation.css" />
	<link rel="stylesheet" href="css/mycss.css" />
    <script src="js/vendor/modernizr.js"></script>
	<style type='text/css'>
      body{ background-image:url("128-36.jpg"); background-repeat:repeat; }
   </style>
  </head>
  
  
  <body>
  <div class="row">
      <div class="large-12 columns">
      	<div class="panel">
	        <a href="index.php" value="" class="button small">Control panel</a>
			<a href="manageads.php" value="" class="button small">&nbsp&nbsp&nbsp&nbsp&nbsp&nbspFree Ads</a>
			<a href="#" value="" class="button small">&nbsp&nbsp&nbsp&nbsp&nbsp&nbspUser Ads</a>
	        <pre><h4><a  href="includes/logout.php" >                                                                                                                        Logout</a></h4></pre>
	    </div>
		
		
		<div class="row">
    <div class="large-12 columns">
      <div class="row collapse">
        
        
      </div>
    </div>
  



<span><h4><?php echo $msg;?></h4></span>   
<center><h4>Users post</h4></center>       
<?php
$total_recs=mysql_num_rows($insertionquery);
	if($total_recs == 0)
	 { 
	 	echo "sorry nothing is posted from users in this category";	
		exit;	
	 } 
else {	



$k=1;
 while($rec=mysql_fetch_array($insertionquery)){?>   	   
    <table align="center">
        

   <tr>
    <th style=" padding-left:10px;">Photo</th>
    <th style=" padding-left:10px;">User name </th>
    <th style=" padding-left:10px;">Ad title </th>
    <th style=" padding-left:10px;">Description </th>
    <th style=" padding-left:10px;">Price </th>
    <th style=" padding-left:10px;">Contact Name </th>
    <th style=" padding-left:10px;">Email </th>
    <th style=" padding-left:10px;">Cell Number</th>
    <th style=" padding-left:10px;">Address </th>
    <!--<td style="color:#b07df4;">Edit </td>-->
    <th style="padding-left:10px;">Delete</th>
  </tr>
  <tr>
    <td id="pic"><img src="../Uploaded/<?php echo $rec['photo_name'];?>"  width="200" height="100" style="border-radius:5px; padding:3px; "/></td>
    <td style="padding-left:10px; width:120px;" ><?php echo $rec['u_name'];?></td>
    <td style="padding-left:10px width:120px;;" ><?php echo $rec['ad_title'];?></td>
    <td style="padding-left:10px; font-size:9px; width:150px;" ><?php echo $rec['description'];?></td>
    <td style="padding-left:10px; width:150px;" ><?php echo $rec['price'];?></td>
    <td style="padding-left:10px; width:150px;" ><?php echo $rec['contact_name'];?></td>
    <td style="padding-left:10px; width:150px;" ><?php echo $rec['email'];?></td>
    <td style="padding-left:10px; width:150px;"><?php echo $rec['m_number'];?></td>
    <td style="padding-left:10px; font-size:9px; width:150px;" ><?php echo $rec['address'];?></td>

    <td style="width:70px;"><a href="deluserpost.php?DELC=<?php echo $rec['id']?>"><img src="../_images/delet.png"/></a></td>

  </tr >
            </table>     
<?php $k++; }
}
?>     


      
  	
 </div>     

    
			
</body>
</html>
