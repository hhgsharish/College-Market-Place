<?php require_once("includes/session.php");?>
<?php
require_once('connection/connection.php');

error_reporting(0);

if(isset($_REQUEST['EDITC']) && $_REQUEST['EDITC']!='')
{
	$editid=$_REQUEST['EDITC'];
	$query="Select * from post2.admin WHERE id='$editid'";
	$insertionquery=mysql_query($query);
	$fetch=mysql_fetch_array($insertionquery);
}
?>


<!doctype html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Free Classifieds..!</title>
    <link rel="stylesheet" href="css/foundation.css" />
	<link rel="stylesheet" href="css/mycss.css" />
    <script src="js/vendor/modernizr.js"></script>
	<style type='text/css'>
      body{ background-image:url("128-36.jpg"); background-repeat:repeat; }
   </style>
  </head>
  
  
  <body>
  <div class="row">
      <div class="large-12 columns">
      	<div class="panel">
	        <a href="index.php" value="" class="button small">Control panel</a>
			
	        <pre><h4><a  href="includes/logout.php" >                                                                                                                        Logout</a></h4></pre>
	    </div>
		
		
		<div class="row">
    <div class="large-12 columns">
      <div class="row collapse">
        
        
      </div>
    </div>
  



<span><h4><?php echo $msg;?></h4></span>   

<div id="page">         
   	  <div id="table">   
		<form id="form" name="form" method="post" action="editadminpros.php">

        	<table align="center">
            	<tr>
                	<td colspan="2" id="tableh2"><b>Edit Your username and password</b></td>
            	</tr>
                
            	<tr>
            	  <td class="text">ID</td>
            	  <td><input name="fr_id" type="text" class="inputfield" id="fr_id" readonly="readonly" value="<?php echo $editid;?>" required/></td>
          	  </tr>
            	<tr>
                	<td width="200" class="text">Enter new name</td>
                    <td width="238"><input  name="fr_title" type="text" class="inputfield" id="fr_title" required> </td>
                    
            	</tr>
                
                
                <tr>
                	<td width="200" class="text">Enter new Password</td>
                    <td width="238"><input  name="pass" type="password" class="inputfield" id="pass" required> </td>
                    
            	</tr>
                
                	<td class="id1"></td>
                  <td><input type="submit" class="inputbutton" value="Edit Now" />
                      <input name="mm" type="hidden" id="mm" value="editmob" /></td>
            	</tr>
            </table>     
        </form>

      </div>
      
  		

      
      	
 </div>     

    
			
</body>
</html>

