

<?php if(isset($_GET['msg']) && $_GET['msg']!='')
{
	$msg=$_GET['msg'];
}
error_reporting(0);
?>

<!doctype html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Free Classifieds..!</title>
    <link rel="stylesheet" href="css/foundation.css" />
	<link rel="stylesheet" href="css/mycss.css" />
    <script src="js/vendor/modernizr.js"></script>
	<style type='text/css'>
      body{ background-image:url("128-36.jpg"); background-repeat:repeat; }
   </style>
  </head>
  
  
  <body>
  
  
    <div class="row">
      <div class="large-12 columns">
      	<div class="panel">
	        <h3>Welcome ...! </h3>
	        <h2>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspAdmin</h2>
	    </div>
		
		
		<div class="row">
    <div class="large-12 columns">
      <div class="row collapse">
        <div class="small-10 columns">
          
        </div>
        <div class="small-2 columns">
          
        </div>
      </div>
    </div>
  </div>
		
 
  
  
		
<form action="loginpros.php" method="post">
<table align="center">
<caption><h3>Admin Login</h3></caption>
  
  <tr>
  <td> Username:</td>
    <td>
	<input name="user" type="text" placeholder="Enter Username" required />
		</td>
  </tr>
  <tr>
  <td> Password:</td>
    <td><input name="pass" type="password" placeholder="Enter Password"  required /></td>
  </tr>
  <tr>
    <td colspan="2"><center><input type="submit" name="btn" class="btn-style" value="Login" /></center></td>
  </tr>
  <tr>
    <td id="error" > <?php echo $msg;?></td>
    <td ><input name="mm" type="hidden" id="mm" value="login" /></td>
  </tr><
</table>
</form>
  
    </div>
	<hr>
	<table  id="footertab" align="center" width="100%">
	
	<tr>
		<td><center>Website Features</center></td>
		<td><center>Useful info</center></td>
		<td><center>Site Map</center></td>
	</tr>
	<tr>
		<td><center>->Post Ads</center></td>
		<td><center>Help</center></td>
		<td><center>find us on facebook</center></td>
	</tr>
	<tr>
		<td><center>->Find jobs</center></td>
		<td><center>Contact us</center></td>
		<td><center>twitter</center></td>
	</tr>
	
</table>
   
   </div>
    
    <script src="js/vendor/jquery.js"></script>
    <script src="js/foundation.min.js"></script>
    <script>
      $(document).foundation();
    </script>
  </body>
</html>
