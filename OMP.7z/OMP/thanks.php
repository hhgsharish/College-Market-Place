<!doctype html>
<html class="no-js" lang="en">
  <head>
  
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Posted Successfuly..!</title>
    <link rel="stylesheet" href="css/foundation.css" />
	<link rel="stylesheet" href="css/mycss.css" />
    <script src=" js/vendor/modernizr.js"></script>
	<style type='text/css'>
      body{ background-image:url("128-36.jpg"); background-repeat:repeat; }
   </style>
  </head>
  
  
  <body>
  
  
    <div class="row">
      <div class="large-12 columns">
      	<div class="panel">
	        
	        <h2>&nbsp&nbsp&nbsp&nbspThanks for using College marketplace!</h2>
	    </div>
		<table>
		<tr>
		<td>Your Ad is posted successfully</td>
		</tr>
		<tr>
		<td>Your Ad is posted succussfully but if
 content found against our policies found in your Ad will be 
 deleted by the admin.You can find your Ad in home page by clicking the same category you posted your Ad</td>
		</tr>
		<tr><td><a  href="index.php" id="register" style="width:200px; margin-left:180px;">Return to home page</a></td></tr>
  
    </div>
	<hr>
	<table  id="footertab" align="center" width="100%">
	
	<tr>
		<td><center>Website Features</center></td>
		<td><center>Useful info</center></td>
		<td><center>Site Map</center></td>
	</tr>
	<tr>
		<td><center>->Post Ads</center></td>
		<td><center>Help</center></td>
		<td><center>find us on facebook</center></td>
	</tr>
	<tr>
		<td><center>->Find jobs</center></td>
		<td><center>Contact us</center></td>
		<td><center>twitter</center></td>
	</tr>
	
</table>
   </div>
   </div>
    
    <script src="js/vendor/jquery.js"></script>
    <script src="js/foundation.min.js"></script>
    <script>
      $(document).foundation();
    </script>
  </body>
</html>
