<?php require_once("_includes/connection.php");
if(isset($_POST['login']) && $_POST['login']=="mmm")
{
	$username=$_POST['usr'];
	$passwprd=$_POST['pwd'];
	$query="SELECT * from post2.user WHERE username='$username' AND u_hash='$passwprd'";
	$reees=mysql_query($query);
	$total_recs=mysql_num_rows($reees);
	if($total_recs == 0)
	{
		header("location:login.php?msg=!!!!! Wrong input check your CAPSLOCK and try again !!!!!");
		exit;	
	}
	if ($total_recs>0)
	{
		$logeduser= $username;
		session_start();
		$_SESSION['users']=$username;
		header("location:user/index.php");
		exit;
	}
	else
	{
		header("location:login.php?msg=!!!! check your CAPSLOCK and try again");
	}
	}


?>