
<?php require_once("../_includes/user_session.php");?>
<?php require_once("../_includes/connection.php"); ?>
<?php require_once("../_includes/functions.php"); ?>
<?php find_selected_page(); ?>
<?php $query="Select * from userad where u_name='$loged_user' ";
$insertionquery=mysql_query($query);?>
<?php {
	$msg=$_GET['msg'];
} ?>
<!doctype html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Free Classifieds..!</title>
    <link rel="stylesheet" href="../css/foundation.css" />
	<link rel="stylesheet" href="../css/mycss.css" />
    <script src="../js/vendor/modernizr.js"></script>
	<style type='text/css'>
      body{ background-image:url("128-36.jpg"); background-repeat:repeat; }
   </style>
  </head>
  
  
  <body>
  
  
    <div class="row">
      <div class="large-12 columns">
      	<div class="panel">
	        <h3>Welcome ...! <a href="../_includes/user_logout.php" value="" style="float:right">Logout</a></h3>
	        <h2>College Marketplace</h2>
	    </div>
		
		
		<div class="row">
    <div class="large-12 columns">
      <div class="row collapse">
        <div class="small-10 columns">
          
		 
		 <a href="user_post.php" class="button small" style="float:right">Post a free Ad</a>
		 <a href="index.php" class="button small" style="float:left"">Go Home</a>
        </div>
        <div class="small-4 columns">
          
        </div>
      </div>
    </div>
  </div>
		
 
  <?php
$total_recs=mysql_num_rows($insertionquery);
	if($total_recs == 0)
	 { 	
		echo "<br/> <br/> <br/>You haven't posted Ad at yet";
		?>
		<a href="index.php">&nbspGo Home </a>
		<?php
		exit;	
	 } 
else {



$k=1;
 while($rec=mysql_fetch_array($insertionquery)){?>
 
<table align="left" width="100%">
  <tr>
    <td style="color:#b07df4;">Ad title</td>
    <td style="color:#b07df4;"> Photo</td>
    <td style="color:#b07df4;">Cell Number</td>
    <td style="color:#b07df4;">Delete</td>
  </tr>
  
  <tr>
    <td ><?php echo $rec['ad_title'];?></td>
    <td id="pic" width="150px">
	<img src="Uploaded/<?php echo $rec['photo_name'];?>"  width="100" height="100" style="border-radius:5px; padding:3px; "/></td>
    <td width="150px"><?php echo $rec['m_number'];?></td>
    <td><a href="deluserpost.php?DELC=<?php echo $rec['id']?>"><img src="../_images/delet.png"/></a></td>

  </tr>
  
</table>
	


<?php $k++; }
}
?>
  		

  
    </div>
	<hr>
	<table  id="footertab" align="center" width="100%">
	
	<tr>
		<td><center>Website Features</center></td>
		<td><center>Useful info</center></td>
		<td><center>Site Map</center></td>
	</tr>
	<tr>
		<td><center>->Post Ads</center></td>
		<td><center>Help</center></td>
		<td><center>find us on facebook</center></td>
	</tr>
	<tr>
		<td><center>->Find jobs</center></td>
		<td><center>Contact us</center></td>
		<td><center>twitter</center></td>
	</tr>
	
</table>
   </div>
   </div>
    
    <script src="../js/vendor/jquery.js"></script>
    <script src="../js/foundation.min.js"></script>
    <script>
      $(document).foundation();
    </script>
  </body>
</html>



