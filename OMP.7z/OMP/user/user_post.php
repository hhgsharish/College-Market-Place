<?php require_once("../_includes/user_session.php");?>
<?php require_once("../_includes/connection.php"); ?>
<?php require_once("../_includes/functions.php"); ?>
<?php find_selected_page(); ?>

<?php if(isset($_GET['msg']) && $_GET['msg']!='')
{
	$msg=$_GET['msg'];
}
error_reporting(0);
?>

<!doctype html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Free Classifieds..!</title>
    <link rel="stylesheet" href="../css/foundation.css" />
	<link rel="stylesheet" href="../css/mycss.css" />
    <script src="../js/vendor/modernizr.js"></script>
	<style type='text/css'>
      body{ background-image:url("128-36.jpg"); background-repeat:repeat; }
   </style>
  </head>
  
  
  <body>
  
  
    <div class="row">
      <div class="large-12 columns">
      	<div class="panel">
	        <h3>Welcome ...! <a href="../_includes/user_logout.php" value="" style="float:right">Logout</a></h3>
	        <h2>College Marketplace</h2>
	    </div>
		
		
		<div class="row">
    <div class="large-12 columns">
      <div class="row collapse">
        
        
      </div>
    </div>
  </div>
		
 
  <form action="user_postpros.php" method="post" enctype="multipart/form-data"">
  <table align="center" width="60%">
  <caption><h3>Post an ad</h3></caption>
	<tr>
		<td colspan="2"><a href</td>
	</tr>
	<tr>
		<td colspan="2"><select name="cat_id" >
								<option value="0">Select a product</option>
								<option value="1">Laptops</option>
								<option value="2">Books</option>
								<option value="3">Mobiles</option>
								<option value="4">Others</option>
						</select></td>
	</tr>
	<tr>
		<td colspan="2"><input type="text" placeholder="*ad title" name="ad_title" required></td>
		<input type="hidden" name="user_id"   value="<?php echo $loged_user; ?>">
	</tr>
	<tr>
		<td><input type="text" name="price"  placeholder="Enter a price" required></td>
		<td>*Add photos:<input type="file" name="photo" id="photo" required></td>
	</tr>
	<tr>
		<td colspan="2"><textarea placeholder="Enter Description" name="description" required></textarea></td>
	</tr>
	
	<tr>
		<td><input type="text" name="contact_name"  placeholder="*Contact Name" required></td>
		<td><input type="text" name="m_number"  placeholder="Contact number" required></td>
	</tr>
	
	<tr>
		<td colspan="2"><input type="email" name="email"  placeholder="*Enter Email ID" required></td>
	</tr>
	<tr>
		<td colspan="2"><input type="text" name="college"  placeholder="*Enter your college name" required></td>
	</tr>
	<tr>
		<td colspan="2"><textarea placeholder="Enter Address" name="address"></textarea></td>
	</tr>
	<tr>
		<td>
		<center><input type="submit" id="submit" class="btn-style" value="POST!" />
		<input type="hidden" name="post" value="mmm" ></center></td>
		<td><center><a href="index.php">Go to home page</a></center></td>
	</tr>
	
</table>
</form>
  
    </div>
	<hr>
	<table  id="footertab" align="center" width="100%">
	
	<tr>
		<td><center>Website Features</center></td>
		<td><center>Useful info</center></td>
		<td><center>Site Map</center></td>
	</tr>
	<tr>
		<td><center>->Post Ads</center></td>
		<td><center>Help</center></td>
		<td><center>find us on facebook</center></td>
	</tr>
	<tr>
		<td><center>->Find jobs</center></td>
		<td><center>Contact us</center></td>
		<td><center>twitter</center></td>
	</tr>
	
</table>
   </div>
   </div>
    
    <script src="../js/vendor/jquery.js"></script>
    <script src="../js/foundation.min.js"></script>
    <script>
      $(document).foundation();
    </script>
  </body>
</html>
